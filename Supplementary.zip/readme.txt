Description: 
The zip file contains supplementary info related to the article: 
A biogeography-based dual-strategy particle swarm algorithm for numerical and engineering design optimization

1 files included in this zip